package com.company.itemanager.ethitemmanagerrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EthItemManagerRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
