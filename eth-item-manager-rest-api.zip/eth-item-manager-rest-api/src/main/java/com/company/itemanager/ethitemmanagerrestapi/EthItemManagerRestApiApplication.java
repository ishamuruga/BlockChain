package com.company.itemanager.ethitemmanagerrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EthItemManagerRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EthItemManagerRestApiApplication.class, args);
	}

}
